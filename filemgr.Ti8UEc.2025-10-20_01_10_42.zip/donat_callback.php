<?php
include_once(__DIR__.'/db.php');

$botToken = "8444453273:AAGPLMEwrLCZyhVq77dWxvH1pDhHrLQvvrg";
$adminChatId = "1269647005"; // O'zgartiring!

function writeLog($message) {
    $logFile = __DIR__ . '/donat_callback.log';
    $time = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$time] $message\n", FILE_APPEND);
}

function sendTelegramMessage($chatId, $message) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}

// Callback ma'lumotlarini olish
$input = file_get_contents('php://input');
$data = json_decode($input, true);

writeLog("📥 Callback keldi: " . $input);
writeLog("📋 GET params: " . json_encode($_GET));

// order_id ni olish (GET yoki POST dan)
$orderId = $_GET['order_id'] ?? $data['order_id'] ?? null;
$chatId = $_GET['chat_id'] ?? $data['chat_id'] ?? null;
$status = $data['status'] ?? null;

writeLog("🔍 Parsed: order_id=$orderId, chat_id=$chatId, status=$status");

// Status tekshirish
if ($status === 'success' && $orderId && $chatId) {
    
    // Donatni bazadan olish
    $stmt = $pdo->prepare("SELECT * FROM donats WHERE order_id = ? AND chat_id = ?");
    $stmt->execute([$orderId, $chatId]);
    $donat = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($donat) {
        writeLog("✅ Donat topildi: ID={$donat['id']}, status={$donat['status']}");
        
        // Agar allaqachon success bo'lsa, qayta ishlatmaymiz
        if ($donat['status'] !== 'success') {
            
            // Statusni yangilash
            $stmt = $pdo->prepare("UPDATE donats SET status = 'success', paid_at = NOW() WHERE id = ?");
            $stmt->execute([$donat['id']]);
            
            writeLog("💾 Status yangilandi");
            
            // Foydalanuvchiga xabar
            $userMsg = "🎉 Tabriklaymiz!\n\n";
            $userMsg .= "Sizning donatiz muvaffaqiyatli qabul qilindi!\n\n";
            $userMsg .= "💰 Summa: " . number_format($donat['amount'], 0, ',', ' ') . " so'm\n";
            $userMsg .= "💬 Xabar: " . htmlspecialchars($donat['message']);
            
            sendTelegramMessage($chatId, $userMsg);
            writeLog("📨 Foydalanuvchiga xabar yuborildi");
            
            // Adminga xabar
            $firstName = $donat['first_name'] ?: 'Noma\'lum';
            $username = $donat['username'] ? "@{$donat['username']}" : 'Yo\'q';
            
            $adminMsg = "🎁 YANGI DONAT!\n\n";
            $adminMsg .= "👤 Ism: $firstName\n";
            $adminMsg .= "📱 Username: $username\n";
            $adminMsg .= "💰 Summa: " . number_format($donat['amount'], 0, ',', ' ') . " so'm\n";
            $adminMsg .= "💬 Xabar:\n<i>" . htmlspecialchars($donat['message']) . "</i>\n\n";
            $adminMsg .= "🆔 Chat ID: $chatId\n";
            $adminMsg .= "📋 Order: $orderId";
            
            sendTelegramMessage($adminChatId, $adminMsg);
            writeLog("📨 Adminga xabar yuborildi");
            
        } else {
            writeLog("⚠️ Donat allaqachon success holatida");
        }
    } else {
        writeLog("❌ Donat topilmadi: order_id=$orderId, chat_id=$chatId");
    }
    
} else {
    writeLog("❌ Status success emas yoki ma'lumot to'liq emas");
}

// InPay ga javob
http_response_code(200);
header('Content-Type: application/json');
echo json_encode(['ok' => true]);
writeLog("✅ Response yuborildi\n" . str_repeat("-", 50));
?>