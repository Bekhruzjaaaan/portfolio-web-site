<?php
// Database konfiguratsiyasi
$host = 'localhost';
$dbname = 'donat321';
$username = 'donat321';
$password = 'donat321';

try {
    // PDO ulanish
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ]
    );
    
    // $conn alias (ba'zi kodlarda ishlatiladi)
    $conn = $pdo;
    
} catch (PDOException $e) {
    // Xatolikni log qilish
    error_log("Database connection error: " . $e->getMessage());
    
    // Foydalanuvchiga umumiy xabar
    die("Ma'lumotlar bazasiga ulanishda xatolik yuz berdi. Iltimos, keyinroq qayta urinib ko'ring.");
}

// Timezone sozlash (ixtiyoriy)
date_default_timezone_set('Asia/Tashkent');

// Helper funksiyalar
function logError($message, $file = 'errors.log') {
    $logPath = __DIR__ . '/' . $file;
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    file_put_contents($logPath, $logMessage, FILE_APPEND);
}

function logInfo($message, $file = 'info.log') {
    $logPath = __DIR__ . '/' . $file;
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $message\n";
    file_put_contents($logPath, $logMessage, FILE_APPEND);
}
?>