<?php
$botToken      = "8444453273:AAGPLMEwrLCZyhVq77dWxvH1pDhHrLQvvrg";
$adminChatId   = "1269647005"; // Admin chat ID
$merchantId    = "47059";
$merchantToken = "e58ba15a565efd342dbd4d5dd2d635c7";
$callbackUrl   = "https://bkhz.uz/donat_callback.php";

include_once(__DIR__.'/db.php');

$update = json_decode(file_get_contents('php://input'), true);

// ================== MESSAGE HANDLER ==================
if (isset($update['message'])) {
    $chatId = $update['message']['chat']['id'];
    $text   = trim($update['message']['text'] ?? '');
    
    $firstName = $update['message']['chat']['first_name'] ?? '';
    $username = $update['message']['chat']['username'] ?? '';

    // Foydalanuvchini bazaga saqlash/yangilash
    $stmt = $pdo->prepare("SELECT * FROM donat_users WHERE chat_id=?");
    $stmt->execute([$chatId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $pdo->prepare("INSERT INTO donat_users (chat_id, first_name, username, state) VALUES (?, ?, ?, 'idle')")
            ->execute([$chatId, $firstName, $username]);
        $user = [
            'id' => $pdo->lastInsertId(), 
            'chat_id' => $chatId,
            'first_name' => $firstName,
            'username' => $username,
            'state' => 'idle'
        ];
    } else {
        $pdo->prepare("UPDATE donat_users SET first_name = ?, username = ? WHERE chat_id = ?")
            ->execute([$firstName, $username, $chatId]);
        $user['first_name'] = $firstName;
        $user['username'] = $username;
    }

    // /start komandasi
    if ($text == "/start") {
        $greeting = $firstName ? "Salom, $firstName! 👋" : "Salom! 👋";
        
        $inlineKeyboard = [
            'inline_keyboard' => [
                [
                    ['text' => "💝 Donat qilish", 'callback_data' => 'start_donat']
                ]
            ]
        ];
        
        sendMessage($chatId, "$greeting\n\n💝 Donat botiga xush kelibsiz!\n\nBu bot orqali siz o'z qo'llab-quvvatlashingizni bildira olasiz.\n\n📝 Jarayon:\n1️⃣ Donat summasini kiriting\n2️⃣ Xabaringizni yozing\n3️⃣ To'lovni amalga oshiring\n\nDonat qilish uchun pastdagi tugmani bosing:", $inlineKeyboard);
        
        $pdo->prepare("UPDATE donat_users SET state = 'idle', temp_amount = NULL, temp_message = NULL WHERE chat_id = ?")
            ->execute([$chatId]);
    }
    
    // Summa kutish holati
    elseif ($user['state'] === 'waiting_amount') {
        if (is_numeric($text) && $text >= 1000) {
            $amount = (int)$text;
            
            $pdo->prepare("UPDATE donat_users SET temp_amount = ?, state = 'waiting_message' WHERE chat_id = ?")
                ->execute([$amount, $chatId]);
            
            $inlineKeyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => "❌ Bekor qilish", 'callback_data' => 'cancel']
                    ]
                ]
            ];
            
            sendMessage($chatId, "✅ Summa qabul qilindi: " . number_format($amount, 0, ',', ' ') . " so'm\n\n💬 Endi xabaringizni yozing:\n\n(Bu xabar admin ko'radi)", $inlineKeyboard);
        } else {
            sendMessage($chatId, "❌ Noto'g'ri summa!\n\nIltimos, 1000 so'mdan yuqori summa kiriting.\n\nMasalan: 5000");
        }
    }
    
    // Xabar kutish holati
    elseif ($user['state'] === 'waiting_message' && $text !== '/start') {
        $message = $text;
        
        $pdo->prepare("UPDATE donat_users SET temp_message = ?, state = 'idle' WHERE chat_id = ?")
            ->execute([$message, $chatId]);
        
        // Yangilangan ma'lumotlarni olish
        $stmt = $pdo->prepare("SELECT * FROM donat_users WHERE chat_id=?");
        $stmt->execute([$chatId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $amount = $user['temp_amount'];
        
        // To'lov yaratish
        $payment = createPayment($merchantId, $merchantToken, $amount, "Donat", $callbackUrl, $chatId);
        
        if ($payment) {
            $payUrl   = $payment['pay_url'];
            $order_id = $payment['order_id'];
            
            // Donat ma'lumotlarini saqlash
            $pdo->prepare("INSERT INTO donats (chat_id, username, first_name, amount, message, order_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())")
                ->execute([$chatId, $username, $firstName, $amount, $message, $order_id]);

            $inlineKeyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => "💳 To'lov qilish", 'url' => "$payUrl"]
                    ],
                    [
                        ['text' => "✅ To'lovni tekshirish", 'callback_data' => "check_$order_id"]
                    ]
                ]
            ];

            sendMessage($chatId, "✅ Hammasi tayyor!\n\n💰 Summa: " . number_format($amount, 0, ',', ' ') . " so'm\n💬 Xabaringiz: $message\n\nTo'lov qilish uchun pastdagi tugmani bosing:", $inlineKeyboard);
        } else {
            sendMessage($chatId, "❌ To'lov yaratishda xatolik yuz berdi. Iltimos, qayta urinib ko'ring.");
        }
    }
}

// ================== CALLBACK HANDLER ==================
if (isset($update['callback_query'])) {
    $callbackId = $update['callback_query']['id'];
    $chatId     = $update['callback_query']['message']['chat']['id'];
    $messageId  = $update['callback_query']['message']['message_id'];
    $data       = $update['callback_query']['data'];

    if ($data === 'start_donat') {
        $pdo->prepare("UPDATE donat_users SET state = 'waiting_amount', temp_amount = NULL, temp_message = NULL WHERE chat_id = ?")
            ->execute([$chatId]);
        
        $inlineKeyboard = [
            'inline_keyboard' => [
                [
                    ['text' => "❌ Bekor qilish", 'callback_data' => 'cancel']
                ]
            ]
        ];
        
        sendEditMessage($chatId, $messageId, "💰 Donat summasini kiriting:\n\n📝 Minimal summa: 1,000 so'm\n\nMasalan: 5000, 10000, 25000", $inlineKeyboard);
    }
    
    elseif ($data === 'cancel') {
        $pdo->prepare("UPDATE donat_users SET state = 'idle', temp_amount = NULL, temp_message = NULL WHERE chat_id = ?")
            ->execute([$chatId]);
        
        $inlineKeyboard = [
            'inline_keyboard' => [
                [
                    ['text' => "💝 Donat qilish", 'callback_data' => 'start_donat']
                ]
            ]
        ];
        
        sendEditMessage($chatId, $messageId, "❌ Bekor qilindi.\n\nYana donat qilmoqchi bo'lsangiz, pastdagi tugmani bosing:", $inlineKeyboard);
    }
    
    elseif (strpos($data, "check_") === 0) {
        $order_id = substr($data, 6);
        
        // check_donat.php orqali tekshirish
        $url = "https://bkhz.uz/check_donat.php?order_id=$order_id&chat_id=$chatId";
        file_get_contents($url);

        $stmt = $pdo->prepare("SELECT * FROM donats WHERE order_id=?");
        $stmt->execute([$order_id]);
        $donat = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($donat && $donat['status'] === 'success') {
            $inlineKeyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => "💳 To'lov cheki", 'web_app' => ['url' => "https://terminal.inpay.uz/$order_id"]]
                    ]
                ]
            ];
            sendEditMessage($chatId, $messageId, "✅ To'lov muvaffaqiyatli amalga oshirildi!\n\n🎉 Rahmat sizning qo'llab-quvvatlashingiz uchun!", $inlineKeyboard);
        } else {
            $payment = createPayment($merchantId, $merchantToken, $donat['amount'], "Donat", $callbackUrl, $chatId);
            $payUrl = $payment['pay_url'] ?? '#';
            
            $inlineKeyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => "💳 To'lov qilish", 'url' => "$payUrl"]
                    ],
                    [
                        ['text' => "✅ To'lovni tekshirish", 'callback_data' => "check_$order_id"]
                    ]
                ]
            ];
            
            sendEditMessage($chatId, $messageId, "⏳ To'lov hali tasdiqlanmagan.\n\nIltimos, to'lovni amalga oshiring va qayta tekshiring:", $inlineKeyboard);
        }
    }
}

// ================== FUNKSIYALAR ==================
function sendMessage($chatId, $message, $keyboard=null) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = ['chat_id'=>$chatId, 'text'=>$message, 'parse_mode'=>'HTML'];
    if ($keyboard) $data['reply_markup'] = json_encode($keyboard);
    file_get_contents($url."?".http_build_query($data));
}

function sendEditMessage($chatId, $messageId, $text, $keyboard) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/editMessageText";
    $data = ['chat_id'=>$chatId, 'message_id'=>$messageId, 'text'=>$text, 'reply_markup'=>json_encode($keyboard), 'parse_mode'=>'HTML'];
    file_get_contents($url."?".http_build_query($data));
}

function getAuthToken($merchantId, $merchantToken) {
    $url = "https://inpay.uz/api/v1/authorization/?merchant_id=$merchantId&merchant_token=$merchantToken";
    $response = file_get_contents($url);
    $data = json_decode($response, true);
    return $data['bearer_token'] ?? null;
}

function createPayment($merchantId, $merchantToken, $amount, $desc, $callbackUrl, $chatId) {
    $authToken = getAuthToken($merchantId, $merchantToken);
    if (!$authToken) return null;

    $url = "https://inpay.uz/create/";
    $data = [
        'merchant_id'  => $merchantId,
        'token'        => $merchantToken,
        'amount'       => (int)$amount,
        'description'  => $desc,
        'callback_url' => $callbackUrl."?chat_id=".$chatId
    ];

    $options = ['http'=>['header'=>"Authorization: Bearer $authToken\r\nContent-Type: application/json\r\n",'method'=>'POST','content'=>json_encode($data)]];
    $context  = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        return null;
    }
    
    $res = json_decode($response, true);

    if (isset($res['pay_url'], $res['order_id'])) {
        return ['pay_url'=>$res['pay_url'],'order_id'=>$res['order_id']];
    }
    
    return null;
}
?>