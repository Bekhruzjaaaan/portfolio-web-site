<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Manzil Topuvchi va Ping Test</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #667eea;
            margin-bottom: 30px;
            font-size: 28px;
        }

        .input-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: border-color 0.3s;
        }

        input:focus {
            outline: none;
            border-color: #667eea;
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        button {
            flex: 1;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        button:active {
            transform: translateY(0);
        }

        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .ping-button {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .result {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            display: none;
        }

        .result.show {
            display: block;
            animation: fadeIn 0.5s;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .result-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e0e0;
        }

        .result-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .result-label {
            font-weight: 600;
            color: #667eea;
            margin-bottom: 5px;
        }

        .result-value {
            color: #333;
            font-size: 18px;
        }

        .ping-results {
            max-height: 300px;
            overflow-y: auto;
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
        }

        .ping-line {
            padding: 5px 0;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: #333;
        }

        .ping-line.success {
            color: #27ae60;
        }

        .ping-line.error {
            color: #e74c3c;
        }

        .ping-stats {
            margin-top: 15px;
            padding: 15px;
            background: #e8f5e9;
            border-radius: 8px;
            font-weight: 600;
            color: #27ae60;
        }

        .counter {
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            background: #e8eaf6;
            border-radius: 10px;
            color: #667eea;
            font-weight: 600;
            font-size: 16px;
        }

        .error {
            color: #e74c3c;
            text-align: center;
            margin-top: 15px;
            padding: 10px;
            background: #fadbd8;
            border-radius: 8px;
            display: none;
        }

        .error.show {
            display: block;
        }

        .loading {
            text-align: center;
            color: #667eea;
            margin-top: 15px;
            display: none;
        }

        .loading.show {
            display: block;
        }

        .progress {
            margin-top: 10px;
            text-align: center;
            color: #667eea;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌐 IP Manzil Topuvchi va Ping Test</h1>
        
        <div class="input-group">
            <label for="domain">Domen yoki URL manzilini kiriting:</label>
            <input type="text" id="domain" placeholder="masalan: google.com yoki https://google.com">
        </div>

        <div class="input-group">
            <label for="pingCount">Qancha marta so'rov yuborish kerak:</label>
            <input type="number" id="pingCount" placeholder="masalan: 10" min="1" max="100" value="10">
        </div>

        <div class="button-group">
            <button onclick="getIP()" id="searchBtn">🔍 IP Topish</button>
            <button onclick="startPing()" id="pingBtn" class="ping-button" disabled>📡 So'rov Yuborish</button>
        </div>

        <div class="loading" id="loading">Qidirilmoqda...</div>
        <div class="error" id="error"></div>

        <div class="result" id="result">
            <div class="result-item">
                <div class="result-label">Domen:</div>
                <div class="result-value" id="domainResult"></div>
            </div>
            <div class="result-item">
                <div class="result-label">IP Manzil:</div>
                <div class="result-value" id="ipResult"></div>
            </div>
        </div>

        <div class="result" id="pingResult">
            <div class="result-label">So'rov Natijalari:</div>
            <div class="progress" id="progress"></div>
            <div class="ping-results" id="pingLog"></div>
            <div class="ping-stats" id="pingStats"></div>
        </div>

        <div class="counter">
            Jami yuborilgan so'rovlar: <span id="requestCount">0</span>
        </div>
    </div>

    <script>
        let requestCount = 0;
        let currentIP = '';

        function extractDomain(input) {
            input = input.trim();
            input = input.replace(/^https?:\/\//, '');
            input = input.replace(/^www\./, '');
            input = input.split('/')[0];
            input = input.split(':')[0];
            return input;
        }

        async function getIP() {
            const domainInput = document.getElementById('domain').value;
            const resultDiv = document.getElementById('result');
            const errorDiv = document.getElementById('error');
            const loadingDiv = document.getElementById('loading');
            const searchBtn = document.getElementById('searchBtn');
            const pingBtn = document.getElementById('pingBtn');
            const pingResultDiv = document.getElementById('pingResult');

            if (!domainInput) {
                errorDiv.textContent = 'Iltimos, domen manzilini kiriting!';
                errorDiv.classList.add('show');
                resultDiv.classList.remove('show');
                return;
            }

            const domain = extractDomain(domainInput);

            errorDiv.classList.remove('show');
            resultDiv.classList.remove('show');
            pingResultDiv.classList.remove('show');
            loadingDiv.classList.add('show');
            searchBtn.disabled = true;
            pingBtn.disabled = true;

            try {
                // Birinchi usul: ipify API
                try {
                    const ipResponse = await fetch(`https://api.allorigins.win/raw?url=https://ipinfo.io/${domain}/json`);
                    const ipData = await ipResponse.json();
                    
                    if (ipData.ip) {
                        currentIP = ipData.ip;
                        document.getElementById('domainResult').textContent = domain;
                        document.getElementById('ipResult').textContent = ipData.ip;
                        resultDiv.classList.add('show');
                        pingBtn.disabled = false;
                        loadingDiv.classList.remove('show');
                        searchBtn.disabled = false;
                        return;
                    }
                } catch (e) {}

                // Ikkinchi usul: DNS Google
                const response = await fetch(`https://dns.google/resolve?name=${domain}&type=A`);
                const data = await response.json();

                loadingDiv.classList.remove('show');
                searchBtn.disabled = false;

                if (data.Answer && data.Answer.length > 0) {
                    const ipAddress = data.Answer[0].data;
                    currentIP = ipAddress;
                    
                    document.getElementById('domainResult').textContent = domain;
                    document.getElementById('ipResult').textContent = ipAddress;
                    
                    resultDiv.classList.add('show');
                    pingBtn.disabled = false;
                } else {
                    errorDiv.textContent = 'IP manzil topilmadi. Domenni tekshiring!';
                    errorDiv.classList.add('show');
                }
            } catch (error) {
                loadingDiv.classList.remove('show');
                searchBtn.disabled = false;
                errorDiv.textContent = 'Xatolik yuz berdi. Internet ulanishingizni tekshiring!';
                errorDiv.classList.add('show');
                console.error('Xatolik:', error);
            }
        }

        async function startPing() {
            if (!currentIP) {
                alert('Avval IP manzilni toping!');
                return;
            }

            const pingCount = parseInt(document.getElementById('pingCount').value) || 10;
            if (pingCount < 1 || pingCount > 100) {
                alert('So\'rovlar soni 1 dan 100 gacha bo\'lishi kerak!');
                return;
            }

            const pingResultDiv = document.getElementById('pingResult');
            const pingLog = document.getElementById('pingLog');
            const pingStats = document.getElementById('pingStats');
            const progress = document.getElementById('progress');
            const pingBtn = document.getElementById('pingBtn');
            const searchBtn = document.getElementById('searchBtn');

            pingLog.innerHTML = '';
            pingStats.innerHTML = '';
            pingResultDiv.classList.add('show');
            pingBtn.disabled = true;
            searchBtn.disabled = true;

            let successCount = 0;
            let failCount = 0;
            let totalTime = 0;
            let minTime = Infinity;
            let maxTime = 0;

            for (let i = 1; i <= pingCount; i++) {
                progress.textContent = `${i} / ${pingCount} - So'rov yuborilmoqda...`;
                
                const startTime = Date.now();
                try {
                    const response = await fetch(`https://${currentIP}`, {
                        method: 'HEAD',
                        mode: 'no-cors',
                        cache: 'no-cache'
                    });
                    const endTime = Date.now();
                    const duration = endTime - startTime;
                    
                    successCount++;
                    totalTime += duration;
                    minTime = Math.min(minTime, duration);
                    maxTime = Math.max(maxTime, duration);
                    
                    const logLine = document.createElement('div');
                    logLine.className = 'ping-line success';
                    logLine.textContent = `${i}. So'rov yuborildi - Vaqt: ${duration}ms`;
                    pingLog.appendChild(logLine);
                    
                    requestCount++;
                    document.getElementById('requestCount').textContent = requestCount;
                } catch (error) {
                    failCount++;
                    const logLine = document.createElement('div');
                    logLine.className = 'ping-line error';
                    logLine.textContent = `${i}. So'rov muvaffaqiyatsiz`;
                    pingLog.appendChild(logLine);
                }
                
                pingLog.scrollTop = pingLog.scrollHeight;
                
                if (i < pingCount) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }

            const avgTime = successCount > 0 ? (totalTime / successCount).toFixed(2) : 0;
            const successRate = ((successCount / pingCount) * 100).toFixed(1);

            pingStats.innerHTML = `
                <div>✅ Muvaffaqiyatli: ${successCount} / ${pingCount} (${successRate}%)</div>
                <div>⏱️ O'rtacha vaqt: ${avgTime}ms</div>
                ${successCount > 0 ? `<div>📊 Min: ${minTime}ms | Max: ${maxTime}ms</div>` : ''}
            `;

            progress.textContent = 'Tugallandi!';
            pingBtn.disabled = false;
            searchBtn.disabled = false;
        }

        document.getElementById('domain').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                getIP();
            }
        });
    </script>
</body>
</html>