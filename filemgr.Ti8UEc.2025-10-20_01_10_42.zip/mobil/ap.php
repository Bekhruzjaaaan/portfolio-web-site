<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music App</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: white;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            overflow: hidden;
            min-height: 100vh;
        }

        .header {
            background: rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav {
            display: flex;
            justify-content: space-around;
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 0;
        }

        .nav-btn {
            background: none;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .nav-btn.active {
            background: rgba(255, 255, 255, 0.2);
        }

        .nav-btn:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .content {
            padding: 20px;
            height: calc(100vh - 200px);
            overflow-y: auto;
        }

        .page {
            display: none;
        }

        .page.active {
            display: block;
        }

        .player {
            background: rgba(0, 0, 0, 0.4);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: center;
        }

        .album-cover {
            width: 200px;
            height: 200px;
            background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
            border-radius: 15px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
        }

        .song-info {
            margin-bottom: 20px;
        }

        .song-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .artist-name {
            font-size: 14px;
            opacity: 0.7;
        }

        .controls {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin: 20px 0;
        }

        .control-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 20px;
            transition: all 0.3s ease;
        }

        .control-btn.play {
            width: 60px;
            height: 60px;
            background: #ff6b6b;
        }

        .control-btn:hover {
            transform: scale(1.1);
        }

        .progress-bar {
            width: 100%;
            height: 5px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 5px;
            margin: 15px 0;
            cursor: pointer;
        }

        .progress {
            height: 100%;
            background: #ff6b6b;
            border-radius: 5px;
            width: 0%;
            transition: width 0.3s ease;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 16px;
        }

        .form-group input::placeholder, .form-group textarea::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .btn {
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #ff5252;
            transform: translateY(-2px);
        }

        .album-item, .song-item {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .album-item:hover, .song-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .album-thumb {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, #4ecdc4, #44a08d);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .album-info h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }

        .album-info p {
            font-size: 12px;
            opacity: 0.7;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
        }

        .search-box {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 20px;
            padding: 12px 20px;
            width: 100%;
            color: white;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .search-box::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .loading {
            text-align: center;
            padding: 20px;
            opacity: 0.7;
        }

        .error {
            background: rgba(255, 0, 0, 0.2);
            border: 1px solid rgba(255, 0, 0, 0.5);
            border-radius: 10px;
            padding: 15px;
            margin: 10px 0;
            text-align: center;
        }

        .success {
            background: rgba(0, 255, 0, 0.2);
            border: 1px solid rgba(0, 255, 0, 0.5);
            border-radius: 10px;
            padding: 15px;
            margin: 10px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎵 Music App</h1>
            <p id="welcomeText">Musiqa dunyosiga xush kelibsiz!</p>
        </div>

        <div class="nav">
            <button class="nav-btn active" onclick="showPage('player')">Player</button>
            <button class="nav-btn" onclick="showPage('library')">Kutubxona</button>
            <button class="nav-btn" onclick="showPage('search')">Qidiruv</button>
            <button class="nav-btn" onclick="showPage('profile')">Profil</button>
        </div>

        <div class="content">
            <!-- Player Page -->
            <div id="player" class="page active">
                <div class="player">
                    <div class="album-cover" id="currentAlbumCover">🎵</div>
                    <div class="song-info">
                        <div class="song-title" id="currentSong">Musiqa tanlang</div>
                        <div class="artist-name" id="currentArtist">Artist</div>
                    </div>
                    <div class="progress-bar" onclick="seekTo(event)">
                        <div class="progress" id="progressBar"></div>
                    </div>
                    <div class="controls">
                        <button class="control-btn" onclick="previousSong()">⏮</button>
                        <button class="control-btn play" id="playBtn" onclick="togglePlay()">▶</button>
                        <button class="control-btn" onclick="nextSong()">⏭</button>
                    </div>
                    <audio id="audioPlayer" preload="metadata" onloadedmetadata="updateDuration()" ontimeupdate="updateProgress()"></audio>
                </div>
            </div>

            <!-- Library Page -->
            <div id="library" class="page">
                <h2>Mening Kutubxonam</h2>
                <div id="albumsList">
                    <!-- Albums will be loaded here -->
                </div>
            </div>

            <!-- Search Page -->
            <div id="search" class="page">
                <input type="text" class="search-box" placeholder="Musiqa, artist yoki albom qidiring..." id="searchInput" onkeyup="searchMusic()">
                <div id="searchResults">
                    <p style="text-align: center; opacity: 0.7;">Qidiruv uchun matn kiriting</p>
                </div>
            </div>

            <!-- Profile Page -->
            <div id="profile" class="page">
                <div class="profile-avatar" id="profileAvatar">👤</div>
                <div id="profileForm">
                    <div class="form-group">
                        <label>Ism</label>
                        <input type="text" id="userName" placeholder="Ismingizni kiriting">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="userEmail" placeholder="Email manzilingizni kiriting">
                    </div>
                    <div class="form-group">
                        <label>Sevimli janr</label>
                        <input type="text" id="favoriteGenre" placeholder="Masalan: Pop, Rock, Jazz">
                    </div>
                    <button class="btn" onclick="saveProfile()">Profilni saqlash</button>
                </div>
                <div id="profileView" style="display: none;">
                    <h3 id="displayName"></h3>
                    <p id="displayEmail"></p>
                    <p id="displayGenre"></p>
                    <button class="btn" onclick="editProfile()">Profilni tahrirlash</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // App state
        let currentSongIndex = 0;
        let isPlaying = false;
        let songs = [];
        let albums = [];
        let userProfile = null;

        // API configuration
        const API_BASE = 'https://uzbek-coder.uz/music/music.php';
        const API_KEY = 'ebba150a259cb2f6d9d47a1c11c78781';

        // Initialize app
        document.addEventListener('DOMContentLoaded', function() {
            loadProfile();
            loadLibrary();
            loadDefaultSongs();
        });

        // Navigation
        function showPage(pageId) {
            // Hide all pages
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            
            // Remove active from all nav buttons
            document.querySelectorAll('.nav-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected page
            document.getElementById(pageId).classList.add('active');
            
            // Add active to clicked button
            event.target.classList.add('active');
        }

        // Music Player Functions
        function togglePlay() {
            const audio = document.getElementById('audioPlayer');
            const playBtn = document.getElementById('playBtn');
            
            if (isPlaying) {
                audio.pause();
                playBtn.innerHTML = '▶';
                isPlaying = false;
            } else {
                if (songs.length > 0) {
                    if (audio.src === '') {
                        loadSong(currentSongIndex);
                    }
                    audio.play();
                    playBtn.innerHTML = '⏸';
                    isPlaying = true;
                } else {
                    showMessage('Avval musiqa tanlang!', 'error');
                }
            }
        }

        function loadSong(index) {
            if (songs.length === 0) return;
            
            const song = songs[index];
            const audio = document.getElementById('audioPlayer');
            
            // Load song from API
            const songUrl = `${API_BASE}?key=${API_KEY}&name=${encodeURIComponent(song.name)}`;
            audio.src = songUrl;
            
            document.getElementById('currentSong').textContent = song.name;
            document.getElementById('currentArtist').textContent = song.artist || 'Noma\'lum artist';
            document.getElementById('currentAlbumCover').textContent = '🎵';
        }

        function nextSong() {
            if (songs.length === 0) return;
            currentSongIndex = (currentSongIndex + 1) % songs.length;
            loadSong(currentSongIndex);
            if (isPlaying) {
                document.getElementById('audioPlayer').play();
            }
        }

        function previousSong() {
            if (songs.length === 0) return;
            currentSongIndex = currentSongIndex === 0 ? songs.length - 1 : currentSongIndex - 1;
            loadSong(currentSongIndex);
            if (isPlaying) {
                document.getElementById('audioPlayer').play();
            }
        }

        function updateProgress() {
            const audio = document.getElementById('audioPlayer');
            const progress = document.getElementById('progressBar');
            
            if (audio.duration) {
                const percentage = (audio.currentTime / audio.duration) * 100;
                progress.style.width = percentage + '%';
            }
        }

        function seekTo(event) {
            const audio = document.getElementById('audioPlayer');
            const progressBar = event.currentTarget;
            const rect = progressBar.getBoundingClientRect();
            const percentage = (event.clientX - rect.left) / rect.width;
            
            if (audio.duration) {
                audio.currentTime = percentage * audio.duration;
            }
        }

        // Search Functions
        let searchTimeout;
        function searchMusic() {
            const query = document.getElementById('searchInput').value.trim();
            const resultsDiv = document.getElementById('searchResults');
            
            clearTimeout(searchTimeout);
            
            if (query.length < 2) {
                resultsDiv.innerHTML = '<p style="text-align: center; opacity: 0.7;">Qidiruv uchun kamida 2 ta harf kiriting</p>';
                return;
            }
            
            searchTimeout = setTimeout(() => {
                resultsDiv.innerHTML = '<div class="loading">Qidirilmoqda...</div>';
                
                // Simulate search with dummy data
                setTimeout(() => {
                    const searchResults = [
                        { name: query + ' - Song 1', artist: 'Artist A', duration: '3:45' },
                        { name: query + ' - Song 2', artist: 'Artist B', duration: '4:12' },
                        { name: query + ' - Song 3', artist: 'Artist C', duration: '3:28' }
                    ];
                    
                    displaySearchResults(searchResults);
                }, 1000);
            }, 500);
        }

        function displaySearchResults(results) {
            const resultsDiv = document.getElementById('searchResults');
            
            if (results.length === 0) {
                resultsDiv.innerHTML = '<p style="text-align: center; opacity: 0.7;">Hech narsa topilmadi</p>';
                return;
            }
            
            let html = '';
            results.forEach((song, index) => {
                html += `
                    <div class="song-item" onclick="playSongFromSearch('${song.name}', '${song.artist}')">
                        <div class="album-thumb">🎵</div>
                        <div class="album-info">
                            <h3>${song.name}</h3>
                            <p>${song.artist} • ${song.duration}</p>
                        </div>
                    </div>
                `;
            });
            
            resultsDiv.innerHTML = html;
        }

        function playSongFromSearch(name, artist) {
            const newSong = { name: name, artist: artist };
            songs.unshift(newSong);
            currentSongIndex = 0;
            loadSong(0);
            showPage('player');
            showMessage('Musiqa pleyerga qo\'shildi!', 'success');
        }

        // Library Functions
        function loadLibrary() {
            const albumsList = document.getElementById('albumsList');
            
            // Load saved albums from memory
            if (albums.length === 0) {
                albumsList.innerHTML = `
                    <div style="text-align: center; opacity: 0.7; padding: 40px;">
                        <p>Hali albomlar qo'shilmagan</p>
                        <p>Qidiruv orqali musiqa qo'shing</p>
                    </div>
                `;
                return;
            }
            
            let html = '';
            albums.forEach((album, index) => {
                html += `
                    <div class="album-item" onclick="playAlbum(${index})">
                        <div class="album-thumb">💿</div>
                        <div class="album-info">
                            <h3>${album.name}</h3>
                            <p>${album.artist} • ${album.songs.length} qo'shiq</p>
                        </div>
                    </div>
                `;
            });
            
            albumsList.innerHTML = html;
        }

        function playAlbum(albumIndex) {
            const album = albums[albumIndex];
            songs = [...album.songs];
            currentSongIndex = 0;
            loadSong(0);
            showPage('player');
            showMessage(`"${album.name}" albomi yuklandi!`, 'success');
        }

        function addToLibrary(songName, artistName) {
            // Find or create album
            let album = albums.find(a => a.artist === artistName);
            if (!album) {
                album = {
                    name: `${artistName} - Albom`,
                    artist: artistName,
                    songs: []
                };
                albums.push(album);
            }
            
            // Add song to album
            const song = { name: songName, artist: artistName };
            album.songs.push(song);
            
            loadLibrary();
            showMessage('Kutubxonaga qo\'shildi!', 'success');
        }

        // Profile Functions
        function saveProfile() {
            const name = document.getElementById('userName').value;
            const email = document.getElementById('userEmail').value;
            const genre = document.getElementById('favoriteGenre').value;
            
            if (!name || !email) {
                showMessage('Ism va email kiritish majburiy!', 'error');
                return;
            }
            
            userProfile = { name, email, genre };
            
            document.getElementById('displayName').textContent = name;
            document.getElementById('displayEmail').textContent = email;
            document.getElementById('displayGenre').textContent = genre ? `Sevimli janr: ${genre}` : '';
            document.getElementById('profileAvatar').textContent = name.charAt(0).toUpperCase();
            document.getElementById('welcomeText').textContent = `Salom, ${name}!`;
            
            document.getElementById('profileForm').style.display = 'none';
            document.getElementById('profileView').style.display = 'block';
            
            showMessage('Profil saqlandi!', 'success');
        }

        function editProfile() {
            document.getElementById('profileForm').style.display = 'block';
            document.getElementById('profileView').style.display = 'none';
        }

        function loadProfile() {
            if (userProfile) {
                document.getElementById('userName').value = userProfile.name;
                document.getElementById('userEmail').value = userProfile.email;
                document.getElementById('favoriteGenre').value = userProfile.genre;
                
                document.getElementById('displayName').textContent = userProfile.name;
                document.getElementById('displayEmail').textContent = userProfile.email;
                document.getElementById('displayGenre').textContent = userProfile.genre ? `Sevimli janr: ${userProfile.genre}` : '';
                document.getElementById('profileAvatar').textContent = userProfile.name.charAt(0).toUpperCase();
                document.getElementById('welcomeText').textContent = `Salom, ${userProfile.name}!`;
                
                document.getElementById('profileForm').style.display = 'none';
                document.getElementById('profileView').style.display = 'block';
            }
        }

        // Load default songs
        function loadDefaultSongs() {
            songs = [
                { name: 'O\'zbek Kuyisi', artist: 'Milliy Artist' },
                { name: 'Vatan Qo\'shig\'i', artist: 'Folklor Guruhi' },
                { name: 'Bahor Sadosi', artist: 'Zamonaviy Ijrochi' }
            ];
            
            // Create default album
            albums = [{
                name: 'O\'zbek Musiqasi',
                artist: 'Turli Ijrochilar',
                songs: songs
            }];
            
            loadLibrary();
            if (songs.length > 0) {
                loadSong(0);
            }
        }

        // Utility Functions
        function showMessage(message, type) {
            const messageDiv = document.createElement('div');
            messageDiv.className = type;
            messageDiv.textContent = message;
            
            document.body.appendChild(messageDiv);
            
            setTimeout(() => {
                messageDiv.remove();
            }, 3000);
        }

        // Audio event listeners
        document.getElementById('audioPlayer').addEventListener('ended', function() {
            nextSong();
        });

        document.getElementById('audioPlayer').addEventListener('error', function() {
            showMessage('Musiqa yuklanmadi. Tarmoq ulanishini tekshiring.', 'error');
            document.getElementById('playBtn').innerHTML = '▶';
            isPlaying = false;
        });

        // Add songs to library from player
        function addCurrentToLibrary() {
            if (songs.length > 0) {
                const currentSong = songs[currentSongIndex];
                addToLibrary(currentSong.name, currentSong.artist);
            }
        }
    </script>
</body>
</html>