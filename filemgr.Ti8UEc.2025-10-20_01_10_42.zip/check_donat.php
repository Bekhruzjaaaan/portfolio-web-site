<?php
include_once(__DIR__.'/db.php');

$orderId = $_GET['order_id'] ?? null;
$chatId = $_GET['chat_id'] ?? null;

if (!$orderId || !$chatId) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing params']);
    exit;
}

$merchantId = "47059";
$merchantToken = "e58ba15a565efd342dbd4d5dd2d635c7";
$botToken = "8444453273:AAGPLMEwrLCZyhVq77dWxvH1pDhHrLQvvrg"; // TO'G'RI TOKEN
$adminChatId = "1269647005"; // SIZNING ADMIN ID

// Log yozish
function logCheck($msg) {
    file_put_contents(__DIR__ . '/check_donat.log', date('Y-m-d H:i:s') . " $msg\n", FILE_APPEND);
}

logCheck("Check boshlandi: order=$orderId, chat=$chatId");

// Auth token olish
function getAuthToken($merchantId, $merchantToken) {
    $url = "https://inpay.uz/api/v1/authorization/?merchant_id=$merchantId&merchant_token=$merchantToken";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    return $data['bearer_token'] ?? null;
}

// To'lov holatini tekshirish
function checkPayment($merchantId, $merchantToken, $orderId) {
    $token = getAuthToken($merchantId, $merchantToken);
    if (!$token) {
        logCheck("Auth token olinmadi");
        return null;
    }
    
    // InPay API - to'lovni tekshirish
    $url = "https://inpay.uz/api/v1/transactions/?order_id=" . urlencode($orderId);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $token",
        "Accept: application/json"
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    logCheck("InPay javob (HTTP $httpCode): $response");
    
    return json_decode($response, true);
}

$paymentStatus = checkPayment($merchantId, $merchantToken, $orderId);

if ($paymentStatus && isset($paymentStatus['status']) && $paymentStatus['status'] === 'success') {
    
    logCheck("To'lov SUCCESS");
    
    // Bazadan donatni olish
    $stmt = $pdo->prepare("SELECT * FROM donats WHERE order_id = ? AND chat_id = ?");
    $stmt->execute([$orderId, $chatId]);
    $donat = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($donat) {
        logCheck("Donat topildi: " . json_encode($donat));
        
        if ($donat['status'] !== 'success') {
            
            // Statusni yangilash
            $stmt = $pdo->prepare("UPDATE donats SET status = 'success', paid_at = NOW() WHERE id = ?");
            $stmt->execute([$donat['id']]);
            
            logCheck("Donat yangilandi: ID={$donat['id']}");
            
            // Adminga xabar
            $firstName = $donat['first_name'] ?: 'Noma\'lum';
            $username = $donat['username'] ? "@{$donat['username']}" : 'Yo\'q';
            
            $adminMsg = "🎁 YANGI DONAT!\n\n";
            $adminMsg .= "👤 $firstName ($username)\n";
            $adminMsg .= "💰 " . number_format($donat['amount'], 0, ',', ' ') . " so'm\n";
            $adminMsg .= "💬 {$donat['message']}\n\n";
            $adminMsg .= "🆔 $chatId\n📋 $orderId";
            
            $url = "https://api.telegram.org/bot$botToken/sendMessage";
            $data = [
                'chat_id' => $adminChatId,
                'text' => $adminMsg,
                'parse_mode' => 'HTML'
            ];
            
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            logCheck("Admin xabari yuborildi (HTTP $httpCode): $result");
        } else {
            logCheck("Donat allaqachon success");
        }
    } else {
        logCheck("❌ Donat topilmadi DB da");
    }
    
    echo json_encode(['status' => 'success']);
    
} else {
    logCheck("To'lov hali pending yoki xatolik");
    echo json_encode(['status' => 'pending']);
}
?>