<?php
// Headers yozilishidan oldin
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>InPay Test</title>
</head>
<body>
    <h2>InPay API Test</h2>
    
<?php
$merchantId = "47059";
$merchantToken = "e58ba15a565efd342dbd4d5dd2d635c7";

echo "<h3>1. Authorization Test:</h3>";

$authUrl = "https://inpay.uz/api/v1/authorization/?merchant_id=$merchantId&merchant_token=$merchantToken";

$ch = curl_init($authUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
$authResponse = curl_exec($ch);
$authHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$authError = curl_error($ch);
curl_close($ch);

echo "HTTP Code: $authHttpCode<br>";
if ($authError) {
    echo "cURL Error: $authError<br>";
}
echo "Response:<br>";
echo "<textarea rows='10' cols='100'>" . htmlspecialchars($authResponse) . "</textarea><br><br>";

$authData = json_decode($authResponse, true);

if (isset($authData['bearer_token'])) {
    echo "<span style='color:green;'>✅ Token olindi!</span><br><br>";
    
    $bearerToken = $authData['bearer_token'];
    
    echo "<h3>2. Payment Creation Test:</h3>";
    
    $paymentData = [
        'merchant_id'  => $merchantId,
        'token'        => $merchantToken,
        'amount'       => 5000,
        'description'  => "Test donat",
        'callback_url' => "https://bkhz.uz/donat_callback.php?chat_id=123456"
    ];
    
    echo "Request:<br>";
    echo "<textarea rows='8' cols='100'>" . json_encode($paymentData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</textarea><br><br>";
    
    $ch = curl_init("https://inpay.uz/create/");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $bearerToken",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paymentData));
    
    $payResponse = curl_exec($ch);
    $payHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $payError = curl_error($ch);
    curl_close($ch);
    
    echo "HTTP Code: $payHttpCode<br>";
    if ($payError) {
        echo "cURL Error: $payError<br>";
    }
    echo "Response:<br>";
    echo "<textarea rows='10' cols='100'>" . htmlspecialchars($payResponse) . "</textarea><br><br>";
    
    $payResult = json_decode($payResponse, true);
    
    if (isset($payResult['pay_url'])) {
        echo "<span style='color:green;'>✅ To'lov yaratildi!</span><br>";
        echo "Pay URL: <a href='{$payResult['pay_url']}' target='_blank'>{$payResult['pay_url']}</a><br>";
        echo "Order ID: {$payResult['order_id']}<br>";
    } else {
        echo "<span style='color:red;'>❌ pay_url topilmadi</span><br>";
    }
    
} else {
    echo "<span style='color:red;'>❌ Token olinmadi</span><br>";
}
?>

</body>
</html>
<?php
ob_end_flush();
?>